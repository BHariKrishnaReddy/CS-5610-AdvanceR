                                        #-----------    Problem 1   -----------#
set.seed(228)
library(ggplot2)
nu <- 4
N <- 10000

# t distribution up to a constant
t_pdf <- function(x, nu) {
  return((1 + (x^2)/nu)^(-(nu + 1)/2))
}

#Cauchy distribution
cauchy_pdf <- function(x) {
  return(dcauchy(x, 0, 1))
}

# sampling algorithm
rejection_sampling <- function(N, nu) {
  samples <- numeric(N)
  accepted <- 0
  
  while (accepted < N) {
    proposal <- rcauchy(1, 0, 1)
    u <- runif(1)
    
    if (u < t_pdf(proposal, nu)/cauchy_pdf(proposal)) {
      samples[accepted + 1] <- proposal
      accepted <- accepted + 1
    }
  }
  
  return(samples)
}

rejection_samples <- rejection_sampling(N, nu)
monte_carlo_estimate <- mean(t_pdf(rejection_samples, nu))

print(paste("Monte Carlo estimate of Ef(X) (Rejection Sampling):", monte_carlo_estimate))

# Metropolis algorithm
metropolis_algorithm <- function(N, nu) {
  samples <- numeric(N)
  current_sample <- 0
  
  for (i in 1:N) {
    proposal <- rnorm(1, current_sample, 1)
    alpha <- min(1, target_pdf(proposal, nu)/target_pdf(current_sample, nu))
    u <- runif(1)
    
    if (u < alpha) {
      current_sample <- proposal
    }
    
    samples[i] <- current_sample
  }
  
  return(samples)
}

metropolis_samples <- metropolis_algorithm(N, nu)

# Calculate percentiles
sample_percentiles <- quantile(metropolis_samples, probs = seq(0, 1, by = 0.1))
t_distribution_percentiles <- qt(seq(0, 1, by = 0.1), nu)

# Compare percentiles
print("Sample percentiles (Metropolis Algorithm):")
print(sample_percentiles)
print("t distribution percentiles:")
print(t_distribution_percentiles)

qqplot(t_distribution_percentiles, sample_percentiles, main = "Q-Q Plot (Metropolis Algorithm)", xlab = "t Distribution Percentiles", ylab = "Sample Percentiles")
abline(0, 1, col = "red")


                                        #-----------    Problem 2   -----------#
#seed is on top !
# pmf for the Sicherman dice
pmf <- c(1/6, 1/6, 1/6, 1/6, 1/6, 1/6)

# Function to perform the Metropolis
metropolis_sicherman <- function(n) {
  outcomes <- c(1, 3, 4, 5, 6, 8)
  sample <- numeric(n)
  counts <- rep(0, length(outcomes))
  current_state <- sample(outcomes, 1, prob = pmf)
  
  for (i in 1:n) {
    proposal <- sample(outcomes, 1, prob = pmf)
    
    # invalid proposals
    if (!(proposal %in% outcomes)) {
      warning("Invalid proposal:", proposal)
      next
    }
    
    alpha <- pmf[proposal] / pmf[current_state]
    
    # Accept or reject based on alpha
    if (is.na(alpha) || runif(1) < alpha) {
      current_state <- proposal
    }
    
    sample[i] <- current_state
    counts[current_state == outcomes] <- counts[current_state == outcomes] + 1
  }
  
  return(list(sample = sample, counts = counts / n))
}

result <- metropolis_sicherman(10000)
print("Relative frequencies:")
print(result$counts)
print("Theoretical probabilities:")
print(pmf)


                                        #-----------    Problem 3   -----------# 

### 1. Monte Carlo methods can be used to solve integral problems. TRUE

### 2. The inverse transform method can always be used to generate discrete random variable when we know the probability mass function (pmf). FALSE

### 3. When we use rejection sampling, the proposal distribution must have the same range (or support) as the target distribution. FALSE

### 4. Importance sampling can be used to calculate the probability of continuous random variable. TRUE

### 5. The main goal of importance sampling is to generate random sample from the target distribution. FALSE

### 6. When we use a Metropolis algorithm we can only use a symmetric proposal distribution. FALSE

### 7. When we use a Metropolis-Hastings algorithm to generate a random sample of 10,000, we need more than 10,000 iterations. TRUE

### 8. If we wish to obtain independent samples from MCMC, we start to collect samples after the burn-in period. TRUE
