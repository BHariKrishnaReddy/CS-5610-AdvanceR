1. R Programming
2. Python
3. SAS
4. Jupyter Notebook
5. MS Excel
6. Google Analytics
